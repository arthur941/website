<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>Project: Holiday card</title>
    </head>
    <body>

        <h1>Happy....  I don't think so? </h1>
<p> Hello everyone, this year I only have eaten <em> pastas </em> .<img src="https://www.kasandbox.org/programming-images/avatars/aqualine-ultimate.png" alt="https://www.bing.com/images/search?view=detailV2&ccid=MtBNzsNg&id=42727A2DED29B46B6488D78F2D07B4ECA2986C77&thid=OIP.MtBNzsNgZKKuUflYUR8adQHaEK&mediaurl=http%3a%2f%2fi1.ytimg.com%2fvi%2fyx3G_yixfnM%2fmaxresdefault.jpg&exph=720&expw=1280&q=pasta&simid=608038304908904014&selectedIndex=0&ajaxhist=0"> </p>

       
        
    </body>
</html>
